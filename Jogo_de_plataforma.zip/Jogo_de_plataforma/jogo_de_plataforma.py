import pygame
import sys
from random import choice

# Inicialização do Pygame
pygame.init()

# Dimensões da tela
WIDTH, HEIGHT = 800, 600
SCREEN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Jogo de Plataforma")

# Cores
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
YELLOW = (255, 255, 0)

# FPS
FPS = 60
clock = pygame.time.Clock()

# Fonte para texto
FONT = pygame.font.SysFont("Arial", 24)

# Carregar a imagem de fundo
background = pygame.image.load("Jogo_de_plataforma/background.png").convert()
background = pygame.transform.scale(background, (WIDTH, HEIGHT))  # Redimensionar para caber na tela

# Classe do jogador
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("Jogo_de_plataforma/cavaleiro.png").convert_alpha()  # Carrega a imagem do personagem
        self.image = pygame.transform.scale(self.image, (50, 50))  # Ajusta o tamanho para 50x50
        self.rect = self.image.get_rect()
        self.rect.center = (WIDTH // 2, HEIGHT - 70)
        self.vel_y = 0
        self.jump_speed = -15
        self.gravity = 0.8

    def update(self, platforms):
        # Movimento horizontal
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.rect.x -= 5
        if keys[pygame.K_RIGHT]:
            self.rect.x += 5

        # Aplicar gravidade
        self.vel_y += self.gravity
        self.rect.y += self.vel_y

        # Checar colisão com plataformas
        if self.vel_y > 0:  # Apenas verificar colisão quando está caindo
            hits = pygame.sprite.spritecollide(self, platforms, False)
            if hits:
                self.rect.bottom = hits[0].rect.top
                self.vel_y = 0

    def jump(self):
        # Pulo somente se o jogador estiver em uma plataforma
        if self.vel_y == 0:
            self.vel_y = self.jump_speed

# Classe das plataformas
class Platform(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height):
        super().__init__()
        self.image = pygame.Surface((width, height))
        self.image.fill(GREEN)
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)

# Classe das moedas
class Coin(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((20, 20))
        self.image.fill(YELLOW)
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

# Função para exibir perguntas em um quadrado na tela principal
def show_question(question_data):
    # Dimensões do retângulo
    rect_width = 600
    rect_height = 200
    rect_x = (WIDTH - rect_width) // 2
    rect_y = (HEIGHT - rect_height) // 2

    # Fonte para perguntas e opções
    question_font = pygame.font.SysFont("Arial", 24)

    while True:
        # Desenhar o fundo e o quadrado
        SCREEN.blit(background, (0, 0))  # Redesenha o fundo
        all_sprites.draw(SCREEN)  # Redesenha os sprites
        pygame.draw.rect(SCREEN, WHITE, (rect_x, rect_y, rect_width, rect_height))  # Retângulo de fundo
        pygame.draw.rect(SCREEN, BLACK, (rect_x, rect_y, rect_width, rect_height), 5)  # Borda preta

        # Exibir a pergunta
        question_text = question_font.render(question_data["question"], True, BLACK)
        SCREEN.blit(question_text, (rect_x + 20, rect_y + 20))

        # Exibir as opções
        for i, option in enumerate(question_data["options"]):
            option_text = question_font.render(option, True, BLACK)
            SCREEN.blit(option_text, (rect_x + 20, rect_y + 60 + i * 30))

        # Atualizar a tela
        pygame.display.flip()

        # Capturar eventos
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                # Verificar se a tecla pressionada corresponde à resposta
                if event.key == pygame.K_a and question_data["answer"] == "A":
                    return True
                if event.key == pygame.K_b and question_data["answer"] == "B":
                    return True
                if event.key == pygame.K_c and question_data["answer"] == "C":
                    return True
                return False

# Tela de transição entre níveis
def show_level_transition(level):
    SCREEN.fill(WHITE)
    text = FONT.render(f"Próximo Nível: {level + 1}", True, BLACK)
    SCREEN.blit(text, (WIDTH // 2 - text.get_width() // 2, HEIGHT // 2 - text.get_height() // 2))
    pygame.display.flip()
    pygame.time.delay(2000)

# Função para carregar o nível
def load_level(level_data):
    # Limpar os grupos
    all_sprites.empty()
    platforms.empty()
    coins.empty()

    # Redefinir a posição do jogador no chão
    player.rect.midbottom = (WIDTH // 2, HEIGHT - 70)
    player.vel_y = 0  # Resetar a velocidade vertical do jogador
    all_sprites.add(player)

    # Adicionar plataformas
    for x, y, width, height in level_data["platforms"]:
        platform = Platform(x, y, width, height)
        all_sprites.add(platform)
        platforms.add(platform)

    # Adicionar moedas
    for x, y in level_data["coins"]:
        coin = Coin(x, y)
        all_sprites.add(coin)
        coins.add(coin)

    # Retornar as perguntas do nível
    return level_data["questions"]

# Lista de níveis
levels = [
    {
        "platforms": [
            (0, HEIGHT - 20, WIDTH, 20),  # Chão
            (100, HEIGHT - 100, 200, 20),
            (350, HEIGHT - 200, 200, 20),
            (200, HEIGHT - 300, 200, 20),
            (400, HEIGHT - 400, 200, 20),
        ],
        "coins": [
            (150, HEIGHT - 120),
            (400, HEIGHT - 220),
            (250, HEIGHT - 320),
            (450, HEIGHT - 420),
        ],
        "questions": [
            {"question": "O que é uma poupança?", "options": ["A. Um tipo de investimento", "B. Um empréstimo", "C. Uma dívida"], "answer": "A"},
            {"question": "Qual é o objetivo de um orçamento?", "options": ["A. Gastar tudo", "B. Planejar despesas", "C. Ignorar receitas"], "answer": "B"},
        ],
    },
    {
        "platforms": [
            (0, HEIGHT - 20, WIDTH, 20),  # Chão
            (150, HEIGHT - 150, 150, 20),
            (300, HEIGHT - 250, 150, 20),
            (100, HEIGHT - 350, 150, 20),
            (400, HEIGHT - 450, 150, 20),
        ],
        "coins": [
            (200, HEIGHT - 170),
            (350, HEIGHT - 270),
            (150, HEIGHT - 370),
            (450, HEIGHT - 470),
        ],
        "questions": [
            {"question": "O que é um investimento?", "options": ["A. Aplicar dinheiro para gerar mais", "B. Gastar sem controle", "C. Deixar o dinheiro parado"], "answer": "A"},
            {"question": "Qual é a vantagem da diversificação?", "options": ["A. Reduzir riscos", "B. Aumentar dívidas", "C. Concentrar ganhos"], "answer": "A"},
        ],
    },
    {
        "platforms": [
            (0, HEIGHT - 20, WIDTH, 20),  # Chão
            (50, HEIGHT - 150, 100, 20),
            (200, HEIGHT - 250, 150, 20),
            (400, HEIGHT - 350, 200, 20),
            (300, HEIGHT - 450, 100, 20),
        ],
        "coins": [
            (75, HEIGHT - 170),
            (250, HEIGHT - 270),
            (450, HEIGHT - 370),
            (350, HEIGHT - 470),
        ],
        "questions": [
            {"question": "Como controlar dívidas?", "options": ["A. Evitar juros altos", "B. Aumentar o gasto", "C. Esquecer o pagamento"], "answer": "A"},
        ],
    }
]

# Inicializar o jogador e grupos
player = Player()
all_sprites = pygame.sprite.Group()
platforms = pygame.sprite.Group()
coins = pygame.sprite.Group()

# Carregar o nível inicial
current_level = 0
questions = load_level(levels[current_level])

# Loop principal do jogo
running = True
while running:
    SCREEN.blit(background, (0, 0))  # Redesenha o fundo
    all_sprites.update(platforms)  # Atualiza todos os sprites
    all_sprites.draw(SCREEN)  # Desenha os sprites

    # Verificar colisão com moedas
    for coin in coins:
        if player.rect.colliderect(coin.rect):
            question_data = choice(questions)  # Seleciona uma pergunta aleatória
            if show_question(question_data):  # Se a resposta for correta
                coins.remove(coin)
                all_sprites.remove(coin)

    # Checar se todas as moedas foram coletadas
    if len(coins) == 0:
        current_level += 1
        if current_level < len(levels):  # Verificar se há mais níveis
            show_level_transition(current_level)
            questions = load_level(levels[current_level])
        else:
            # Fim do jogo
            SCREEN.fill(WHITE)
            text = FONT.render("Parabéns! Você completou o jogo!", True, BLACK)
            SCREEN.blit(text, (WIDTH // 2 - text.get_width() // 2, HEIGHT // 2 - text.get_height() // 2))
            pygame.display.flip()
            pygame.time.delay(3000)
            running = False

    pygame.display.flip()
    clock.tick(FPS)

pygame.quit()
